% LAL = likelihood active learning

clearvars
rng(100,'twister')
uqlab

%% Bayesian inversion definition (single measurement)

% Measurement (single)
measurement = 8.                 % measurement value
measurement_error = 0.8   % measurement confindence interval = 2 * std 

% Prior definition
PriorOpts.Name = 'Prior'
PriorOpts.Marginals(1).Type = 'Gaussian'    % prior form
PriorOpts.Marginals(1).Moments = [0., 4.]   % prior mean and variance
PriorInput = uq_createInput(PriorOpts);

% Model definition
a = 2
ModelOpts.Name = 'myModel';
ModelOpts.mFile = 'myModel'           % model selection
ModelOpts.Parameters.a = a;
myModel = uq_createModel(ModelOpts);  


%% Likelihood definition for inversion
LOpts.Name = 'log_likelihood_model';
LOpts.mFile = 'log_likelihood_model';
LOpts.Parameters.Model = myModel;
LOpts.Parameters.Measurement = measurement;
LOpts.Parameters.Discrepancy = (measurement_error / 2)^2;     % discrepancy model

LogLikelihoodModel = uq_createModel(LOpts);

%% LAL setup and hyperparameters tuning

LALOpts.Bus.c = sqrt(2*pi*LOpts.Parameters.Discrepancy) * 1.5    % best value: 1 / (max L + small_quantity) 
LALOpts.Bus.p0 = 0.1                            % Quantile probability for Subset
LALOpts.Bus.BatchSize = 1e5                             % Number of samples for Subset simulation
LALOpts.MaximumEvaluations = 20

LALOpts.ExpDesign.X = uq_getSample(10);
LALOpts.ExpDesign.LogLikelihood = uq_evalModel(LogLikelihoodModel, LALOpts.ExpDesign.X);

LALOpts.PCE.MinDegree = 2;
LALOpts.PCE.MaxDegree = 12;

LALOpts.LogLikelihood = LogLikelihoodModel;
LALOpts.Prior = PriorInput;

LALAnalysis = lal_analysis(LALOpts);


%% Likelihood visualization

% Get analytical curve
x_ana = linspace(-4.5, 4.5, 1000);
L_ana = exp(uq_evalModel(LogLikelihoodModel, x_ana));

% Plot Likelihood experimental design
figure
hold on
plot(x_ana, L_ana)
scatter(LALAnalysis.ExpDesign.X, exp(LALAnalysis.ExpDesign.LogLikelihood), 'filled')
hold off
xlab = xlabel('$x$');
set(xlab, 'Interpreter','latex');
ylab = ylabel('$\mathcal{L}$');
set(ylab, 'Interpreter','latex');
title('Likelihood approximation experimental design');
lgd = legend('Analytical curve', 'LAL evaluations');
set(lgd, 'Interpreter','latex');
lgd.Location = 'northwest';

%% PCK of likelihood

% Construct a PC-Kriging surrogate of the log-likelihood
PCKOpts.Type = 'Metamodel';
PCKOpts.MetaType = 'PCK';
PCKOpts.Mode = 'sequential';
PCKOpts.FullModel = LogLikelihoodModel;
PCKOpts.PCE.Degree = LALOpts.PCE.MinDegree:2:LALOpts.PCE.MaxDegree;
PCKOpts.PCE.Method = 'LARS';
PCKOpts.ExpDesign.X = LALAnalysis.ExpDesign.X;
PCKOpts.ExpDesign.Y = LALAnalysis.ExpDesign.LogLikelihood;
PCKOpts.Kriging.Corr.Family = 'Gaussian';

logL_PCK = uq_createModel(PCKOpts);

logL_PCK.Error

%% Get samples and draw an histogram

N_samples = 1e4;

BayesOpts.Prior = PriorInput;
BayesOpts.LogLikelihood = logL_PCK;
BayesOpts.Bus = LALOpts.Bus;
BayesOpts.Bus.BatchSize = N_samples;

BayesAnalysis = bus_analysis(BayesOpts);

% Get some prior samples
uq_selectInput('Prior');
prior_samples_X = uq_getSample(N_samples);

figure
hold on
histogram(prior_samples_X)
histogram(BayesAnalysis.Results.PostSamples)
hold off
xlab = xlabel('$X$');
set(xlab, 'Interpreter','latex');
ylabel('Occurrences');
title('Prior vs Posterior sample comparison');
lgd = legend('Prior', 'Posterior');
lgd.Location = 'northwest';
set(lgd,'Interpreter','latex');

